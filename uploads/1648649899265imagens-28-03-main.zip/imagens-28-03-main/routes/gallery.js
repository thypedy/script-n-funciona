module.exports = (app)=>{

    //importar o config database
    var database = require('../config/database')
    //importar o model gallery
    var gallery = require('../models/gallery')
    
    //exibir o formulario gallery.ejs
    app.get('/gallery',async(req,res)=>{
        //conectar com o database
        database()
        //executar a busca de documentos da coleção gallery
        var documentos = await gallery.find()
        res.render('gallery.ejs',{dados:documentos})
    })

    //importar a config do molter
    var multer = require('../config/multer')
    //upload do arquivo
    app.post('/gallery',multer.single('imagem'),async(req,res)=>
    {
        //conectar o database
        database()
        //gravar o nome do arquivo na coleção gallery
        var documento = await new gallery({
            arquivo:req.file.filename
        }).save()
        res.redirect('/gallery')
    })
}